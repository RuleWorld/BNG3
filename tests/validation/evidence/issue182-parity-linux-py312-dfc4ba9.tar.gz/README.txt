Exact-source issue #182 manual CI wiring receipt, executed 2026-10-10 UTC.
Run: https://github.com/RuleWorld/BNG3/actions/runs/38076443040
Numerical job: https://github.com/RuleWorld/BNG3/actions/runs/38076443040/job/114289959352
Hosted artifact: https://github.com/RuleWorld/BNG3/actions/runs/38076443040/artifacts/11680175312

Required RHS/ODE/SSA determinism/export lane: 60 passed, no failures/errors/skips; three slow ensemble tests deselected in that step.
Scheduled lane: all three 200-member frozen cohorts executed; two passed, michment failed with unchanged 10/306 mean violations and worst z 9.344938257977688 at ScT. No seeds, horizons, tolerance, exclusion, skip, expected output or golden changes.
Exact installed package/native/model and spawned worker identity passed. The source, git and expected head all agree. The unit bridge and C++ writer candidates were not integrated and are excluded.
Overall workflow failed. Separate historical NFsim job ran 74 tests with 3 failures and 3 errors: v17 dynamic scoped-rate rejection, two v19 parser errors, r21 statistical failure after the unchanged 30 deterministic seeds, and two empty-reference assertions. Their scope remains unresolved in #146; strict native -oSteps parity remains red separately.
This is gate execution/provenance evidence, not full stochastic, NFsim, SBML, formal or release qualification.
